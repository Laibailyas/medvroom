# MedVroom — Auth Drop-in

Complete authentication layer for **MedVroom**: patient login/register, provider login/register, email verification, password reset, and Google OAuth — with role-based dashboard redirects.

---

## What's included

| File | Purpose |
|---|---|
| `app/Http/Controllers/Auth/AuthenticatedSessionController.php` | Patient login & logout |
| `app/Http/Controllers/Auth/ProviderSessionController.php` | Provider login & logout |
| `app/Http/Controllers/Auth/RegisteredUserController.php` | Patient registration |
| `app/Http/Controllers/Auth/RegisteredDoctorController.php` | Provider registration |
| `app/Http/Controllers/Auth/EmailVerificationController.php` | Email verify notice/send/confirm |
| `app/Http/Controllers/Auth/PasswordResetLinkController.php` | Forgot-password form + email |
| `app/Http/Controllers/Auth/NewPasswordController.php` | Reset-password form + save |
| `app/Http/Controllers/Auth/ConfirmablePasswordController.php` | Confirm-password gate |
| `app/Http/Controllers/Auth/SocialAuthController.php` | Google OAuth |
| `app/Http/Requests/Auth/LoginRequest.php` | Login validation + rate-limiting |
| `app/Http/Middleware/RedirectIfAuthenticated.php` | Redirects logged-in users to their dashboard |
| `app/Http/Middleware/EnsureEmailIsVerified.php` | Blocks unverified users |
| `app/Models/User.php` | User model with patient + provider columns |
| `app/Providers/RouteServiceProvider.php` | Registers auth routes |
| `database/migrations/…_create_users_table.php` | Full users table migration |
| `routes/auth.php` | All auth routes (patient, provider, password, social) |

---

## Installation

### 1. Copy files

Copy every file from this package into the matching path in your Laravel project. **Do not overwrite** any existing files you have customized — merge manually if needed.

### 2. Run migration

```bash
php artisan migrate
```

If you already have a `users` table, create a new migration to **add the missing columns** instead:

```bash
php artisan make:migration add_medvroom_columns_to_users_table
```

Then add the columns from the migration file in this package.

### 3. Configure `.env` for email (SMTP)

```env
MAIL_MAILER=smtp
MAIL_HOST=smtp.mailgun.org        # or smtp.sendgrid.net / smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your_smtp_username
MAIL_PASSWORD=your_smtp_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=no-reply@medvroom.com
MAIL_FROM_NAME="MedVroom"
```

> **Tip:** During development you can use `MAIL_MAILER=log` to write verification emails to `storage/logs/laravel.log` instead of actually sending them — no SMTP needed.

### 4. Configure Google OAuth (for "Continue with Google")

Install Socialite if you haven't:

```bash
composer require laravel/socialite
```

Add to `.env`:

```env
GOOGLE_CLIENT_ID=your_google_client_id
GOOGLE_CLIENT_SECRET=your_google_client_secret
GOOGLE_REDIRECT_URI=https://yourapp.com/auth/google/callback
```

Add to `config/services.php`:

```php
'google' => [
    'client_id'     => env('GOOGLE_CLIENT_ID'),
    'client_secret' => env('GOOGLE_CLIENT_SECRET'),
    'redirect'      => env('GOOGLE_REDIRECT_URI'),
],
```

In Google Cloud Console → OAuth 2.0 → add `https://yourapp.com/auth/google/callback` as an **Authorized redirect URI**.

### 5. Register Middleware

In `app/Http/Kernel.php`, ensure these aliases exist in `$middlewareAliases` (or `$routeMiddleware` in older Laravel):

```php
'guest'    => \App\Http\Middleware\RedirectIfAuthenticated::class,
'verified' => \App\Http\Middleware\EnsureEmailIsVerified::class,
```

### 6. Create your dashboard routes

Add these to `routes/web.php` (protected by `auth` + `verified`):

```php
// Patient dashboard
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', fn() => view('patient.dashboard'))
        ->name('patient.dashboard');
});

// Provider dashboard
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/provider/dashboard', fn() => view('provider.dashboard'))
        ->name('provider.dashboard');

    // Onboarding entry point (pre-verification redirect for new providers)
    Route::get('/provider/onboarding', fn() => view('provider-onboarding.entry'))
        ->name('provider.onboarding.entry');
});
```

---

## How auth flow works

### Patient registration
1. `GET /register` → `register-patient.blade.php`
2. `POST /register` → creates User with `role = 'patient'`, fires `Registered` event
3. Sends **verification email** automatically via Laravel's built-in `MustVerifyEmail`
4. Redirects to `/email/verify` (notice page)
5. User clicks link in email → `GET /email/verify/{id}/{hash}` → marks verified → redirects to `patient.dashboard`

### Provider registration
1. `GET /provider/register` → `register-doctor.blade.php`
2. `POST /provider/register` → creates User with `role = 'doctor'`, `onboarding_completed = false`
3. Same email verification flow
4. After verification → redirects to `provider.onboarding.entry` (since `onboarding_completed` is `false`)
5. Once onboarding is done, set `onboarding_completed = true` → future logins go to `provider.dashboard`

### Login (both roles)
- Patient: `POST /login` — validates role is `patient`, else rejects
- Provider: `POST /provider/login` — validates role is `doctor`, else rejects
- After login, `RedirectIfAuthenticated` middleware handles role routing automatically

### Email verification
- The `User` model implements `MustVerifyEmail` — Laravel handles token generation + link building automatically
- Just make sure SMTP is set in `.env`
- During dev, use `MAIL_MAILER=log` and grab the link from `storage/logs/laravel.log`

---

## Common issues

| Problem | Fix |
|---|---|
| Verification email not sending | Check `MAIL_MAILER`, `MAIL_HOST`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD` in `.env`. Run `php artisan config:clear`. |
| "Route not defined" errors | Make sure `routes/auth.php` is loaded in `RouteServiceProvider` or `web.php` via `require`. |
| Redirecting to `/home` after login | Your `RedirectIfAuthenticated` middleware is the old default — replace it with the one in this package. |
| Google OAuth "redirect_uri_mismatch" | The redirect URI in your `.env` and Google Cloud Console must match exactly (including http vs https). |
| Provider can log in as patient | Each login controller checks `$user->role` and rejects mismatches — make sure you're using the correct controllers. |
| `onboarding_completed` not saving | Make sure `onboarding_completed` is in `$fillable` on the User model (it is in this package). |
