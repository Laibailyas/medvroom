<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        // Shared
        'first_name',
        'last_name',
        'name',
        'email',
        'mobile',
        'password',
        'role',                  // 'patient' | 'doctor' | 'admin'

        // Patient-specific
        'date_of_birth',
        'sex',
        'extended_gender',

        // Provider-specific
        'practice_name',
        'practice_specialty',
        'practice_size',
        'practice_zip_code',
        'referral_source',
        'onboarding_completed',

        // Social auth
        'google_id',
        'avatar',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at'    => 'datetime',
        'password'             => 'hashed',
        'extended_gender'      => 'array',
        'onboarding_completed' => 'boolean',
        'date_of_birth'        => 'date',
    ];

    // ─── Role Helpers ────────────────────────────────────────────────────────

    public function isPatient(): bool
    {
        return $this->role === 'patient';
    }

    public function isDoctor(): bool
    {
        return $this->role === 'doctor';
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function getFullNameAttribute(): string
    {
        return trim("{$this->first_name} {$this->last_name}");
    }

    // ─── Dashboard Route Helper ───────────────────────────────────────────────

    public function dashboardRoute(): string
    {
        return match ($this->role) {
            'doctor' => $this->onboarding_completed
                ? 'provider.dashboard'
                : 'provider.onboarding.entry',
            'admin'  => 'admin.dashboard',
            default  => 'patient.dashboard',
        };
    }
}
