<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

class RegisteredUserController extends Controller
{
    /**
     * Display the patient registration view.
     */
    public function create(): View
    {
        return view('auth.register-patient');
    }

    /**
     * Handle an incoming patient registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'first_name'      => ['required', 'string', 'max:255'],
            'last_name'       => ['required', 'string', 'max:255'],
            'email'           => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:users,email'],
            'mobile'          => ['required', 'string', 'max:20'],
            'date_of_birth'   => ['required', 'date', 'before:today'],
            'sex'             => ['required', 'in:male,female'],
            'extended_gender' => ['nullable', 'array'],
            'extended_gender.*' => ['string', 'max:100'],
            'password'        => ['required', 'confirmed', Password::defaults()],
        ]);

        $user = User::create([
            'first_name'      => $request->first_name,
            'last_name'       => $request->last_name,
            'name'            => $request->first_name . ' ' . $request->last_name,
            'email'           => $request->email,
            'mobile'          => $request->mobile,
            'date_of_birth'   => $request->date_of_birth,
            'sex'             => $request->sex,
            'extended_gender' => $request->extended_gender ?? [],
            'password'        => Hash::make($request->password),
            'role'            => 'patient',
        ]);

        // Fire Registered event — triggers the email verification notification
        event(new Registered($user));

        Auth::login($user);

        return redirect()->route('verification.notice');
    }
}
