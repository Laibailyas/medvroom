<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

class SocialAuthController extends Controller
{
    /**
     * Redirect the user to the OAuth provider (e.g. Google).
     */
    public function redirect(string $provider): RedirectResponse
    {
        abort_unless(in_array($provider, ['google']), 404);

        return Socialite::driver($provider)->redirect();
    }

    /**
     * Handle the OAuth callback and log the user in (or create their account).
     */
    public function callback(string $provider): RedirectResponse
    {
        abort_unless(in_array($provider, ['google']), 404);

        try {
            $socialUser = Socialite::driver($provider)->user();
        } catch (\Exception $e) {
            return redirect()->route('login')
                ->withErrors(['email' => 'Unable to authenticate with ' . ucfirst($provider) . '. Please try again.']);
        }

        // Try to find existing user by provider ID or email
        $user = User::where('google_id', $socialUser->getId())
            ->orWhere('email', $socialUser->getEmail())
            ->first();

        if ($user) {
            // Update social ID if this is a new link
            if (! $user->google_id) {
                $user->update(['google_id' => $socialUser->getId()]);
            }

            // Mark email as verified since Google has already done that
            if (! $user->hasVerifiedEmail()) {
                $user->markEmailAsVerified();
            }
        } else {
            // Create a brand-new patient account
            $nameParts = explode(' ', $socialUser->getName(), 2);

            $user = User::create([
                'first_name'       => $nameParts[0] ?? $socialUser->getName(),
                'last_name'        => $nameParts[1] ?? '',
                'name'             => $socialUser->getName(),
                'email'            => $socialUser->getEmail(),
                'google_id'        => $socialUser->getId(),
                'avatar'           => $socialUser->getAvatar(),
                'role'             => 'patient',
                'email_verified_at' => now(), // Google verifies email
                'password'         => null,
            ]);

            event(new Registered($user));
        }

        Auth::login($user, remember: true);

        return redirect()->route($user->dashboardRoute());
    }
}
