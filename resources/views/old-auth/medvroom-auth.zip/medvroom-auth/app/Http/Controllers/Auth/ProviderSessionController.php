<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class ProviderSessionController extends Controller
{
    /**
     * Display the provider login view.
     */
    public function create(): View
    {
        return view('auth.login', ['role' => 'doctor']);
    }

    /**
     * Handle an incoming provider authentication request.
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();

        $request->session()->regenerate();

        $user = Auth::user();

        // Ensure the user has the doctor/provider role
        if ($user->role !== 'doctor') {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return back()->withErrors([
                'email' => 'These credentials do not match a provider account.',
            ])->onlyInput('email');
        }

        // Providers may require onboarding completion
        if (! $user->onboarding_completed) {
            return redirect()->route('provider.onboarding.entry');
        }

        return redirect()->intended(route('provider.dashboard'));
    }

    /**
     * Destroy an authenticated provider session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('provider.login');
    }
}
