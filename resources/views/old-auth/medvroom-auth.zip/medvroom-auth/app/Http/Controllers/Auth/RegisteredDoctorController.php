<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

class RegisteredDoctorController extends Controller
{
    /**
     * Display the provider registration view.
     */
    public function create(): View
    {
        return view('auth.register-doctor');
    }

    /**
     * Handle an incoming provider registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'first_name'         => ['required', 'string', 'max:255'],
            'last_name'          => ['required', 'string', 'max:255'],
            'email'              => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:users,email'],
            'mobile'             => ['required', 'string', 'max:20'],
            'password'           => ['required', 'confirmed', Password::defaults()],
            'practice_name'      => ['required', 'string', 'max:255'],
            'practice_specialty' => ['required', 'string', 'max:100'],
            'practice_size'      => ['required', 'string', 'max:20'],
            'practice_zip_code'  => ['required', 'string', 'max:10'],
            'referral_source'    => ['nullable', 'string', 'max:100'],
            'terms'              => ['accepted'],
        ]);

        $user = User::create([
            'first_name'           => $request->first_name,
            'last_name'            => $request->last_name,
            'name'                 => $request->first_name . ' ' . $request->last_name,
            'email'                => $request->email,
            'mobile'               => $request->mobile,
            'password'             => Hash::make($request->password),
            'role'                 => 'doctor',
            'practice_name'        => $request->practice_name,
            'practice_specialty'   => $request->practice_specialty,
            'practice_size'        => $request->practice_size,
            'practice_zip_code'    => $request->practice_zip_code,
            'referral_source'      => $request->referral_source,
            'onboarding_completed' => false,
        ]);

        // Fire Registered event — triggers the email verification notification
        event(new Registered($user));

        Auth::login($user);

        return redirect()->route('verification.notice');
    }
}
