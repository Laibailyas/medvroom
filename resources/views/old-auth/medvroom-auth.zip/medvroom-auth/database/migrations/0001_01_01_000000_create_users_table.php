<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();

            // ─── Core / Shared ───────────────────────────────────────────
            $table->string('name');
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('email')->unique();
            $table->string('mobile')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password')->nullable(); // nullable for social-only users
            $table->string('role')->default('patient'); // patient | doctor | admin
            $table->rememberToken();
            $table->timestamps();

            // ─── Patient-specific ────────────────────────────────────────
            $table->date('date_of_birth')->nullable();
            $table->string('sex')->nullable();              // male | female
            $table->json('extended_gender')->nullable();    // array of optional identities

            // ─── Provider-specific ───────────────────────────────────────
            $table->string('practice_name')->nullable();
            $table->string('practice_specialty')->nullable();
            $table->string('practice_size')->nullable();
            $table->string('practice_zip_code')->nullable();
            $table->string('referral_source')->nullable();
            $table->boolean('onboarding_completed')->default(false);

            // ─── Social Auth ─────────────────────────────────────────────
            $table->string('google_id')->nullable()->unique();
            $table->string('avatar')->nullable();
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
