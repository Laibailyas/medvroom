<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\ConfirmablePasswordController;
use App\Http\Controllers\Auth\EmailVerificationController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\ProviderSessionController;
use App\Http\Controllers\Auth\RegisteredDoctorController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\Auth\SocialAuthController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Guest-only routes (redirects authenticated users away)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {

    // ── Patient Auth ─────────────────────────────────────────────────────────

    Route::get('/login', [AuthenticatedSessionController::class, 'create'])
        ->name('login');

    Route::post('/login', [AuthenticatedSessionController::class, 'store']);

    Route::get('/register', [RegisteredUserController::class, 'create'])
        ->name('register');

    Route::post('/register', [RegisteredUserController::class, 'store']);

    // ── Provider Auth ─────────────────────────────────────────────────────────

    Route::get('/provider/login', [ProviderSessionController::class, 'create'])
        ->name('provider.login');

    Route::post('/provider/login', [ProviderSessionController::class, 'store']);

    Route::get('/provider/register', [RegisteredDoctorController::class, 'create'])
        ->name('register.doctor');

    Route::post('/provider/register', [RegisteredDoctorController::class, 'store']);

    // ── Social Auth (Google OAuth) ────────────────────────────────────────────

    Route::get('/auth/{provider}/redirect', [SocialAuthController::class, 'redirect'])
        ->name('social.redirect');

    Route::get('/auth/{provider}/callback', [SocialAuthController::class, 'callback'])
        ->name('social.callback');

    // ── Password Reset (shared) ───────────────────────────────────────────────

    Route::get('/forgot-password', [PasswordResetLinkController::class, 'create'])
        ->name('password.request');

    Route::post('/forgot-password', [PasswordResetLinkController::class, 'store'])
        ->name('password.email');

    Route::get('/reset-password/{token}', [NewPasswordController::class, 'create'])
        ->name('password.reset');

    Route::post('/reset-password', [NewPasswordController::class, 'store'])
        ->name('password.store');
});

/*
|--------------------------------------------------------------------------
| Authenticated routes
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->group(function () {

    // ── Email Verification ────────────────────────────────────────────────────

    Route::get('/email/verify', [EmailVerificationController::class, 'notice'])
        ->name('verification.notice');

    Route::get('/email/verify/{id}/{hash}', [EmailVerificationController::class, 'verify'])
        ->middleware(['signed', 'throttle:6,1'])
        ->name('verification.verify');

    Route::post('/email/verification-notification', [EmailVerificationController::class, 'send'])
        ->middleware('throttle:6,1')
        ->name('verification.send');

    // ── Confirm Password ──────────────────────────────────────────────────────

    Route::get('/confirm-password', [ConfirmablePasswordController::class, 'show'])
        ->name('password.confirm');

    Route::post('/confirm-password', [ConfirmablePasswordController::class, 'store']);

    // ── Logout (patient) ──────────────────────────────────────────────────────

    Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])
        ->name('logout');

    // ── Logout (provider) ─────────────────────────────────────────────────────

    Route::post('/provider/logout', [ProviderSessionController::class, 'destroy'])
        ->name('provider.logout');
});
